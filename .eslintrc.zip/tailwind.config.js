/** @type {import('tailwindcss').Config} */
module.exports = {
   content: ["./src/**/*.{html,jsx}"],
   theme: {
      extend: {
         colors: {
            blue: "#471AAA",
            "gray-white": "#f0f0f0",
            "darky-blue": "rgb(20, 8, 96)",
         },
      },
   },
   plugins: [],
};
