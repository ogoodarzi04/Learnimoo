import React from 'react'
import { useState,useEffect} from 'react'
export default function useFetch() {
    const [post,setPost]=useState([])
    const [isPending,setisPending]=useState(true)
    const [err,setErr]=useState(null)
    const getAllProducts=(url)=>{
        fetch(url)
        .then(post=>post.json())
        .then(data=>{
     setPost(data)
     setisPending(false)
    setErr(null)
    }

)

.catch(err=>console.log(err))
    }
    // useEffect(()=>{
        // setTimeout(() => {
         
        // },);
      
    // },[])
    return {getAllProducts,post,isPending,err}
}
