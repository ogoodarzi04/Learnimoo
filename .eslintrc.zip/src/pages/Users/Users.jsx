import React from 'react'
import './Users.css'
import ErrBox from '../../Components/ErrBox/ErrBox'
export default function Users() {
  return (
    <div>Users
<ErrBox titleErr={'کاربری'}/>
    </div>
  )
}
