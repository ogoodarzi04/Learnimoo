import React from 'react'
import './Discounts.css'
import ErrBox from '../../Components/ErrBox/ErrBox'
export default function Discounts() {
  return (
    <div>Discounts
      <ErrBox titleErr={'کد تخفیفی'}/>
    </div>
  )
}
