import React from 'react'
import './SideBar.css'
import { AiOutlineHome } from "react-icons/ai";
import { MdProductionQuantityLimits } from "react-icons/md";
import { BiCommentDetail } from "react-icons/bi";
import { FiUsers } from "react-icons/fi";
import { BsBagCheck, BsCurrencyDollar } from "react-icons/bs";
import { NavLink,Link } from 'react-router-dom';
export default function SideBar() {
  return (
    <>
    <div className='SideBar bg-blue w-full ' >
<div className="SideBar-title   py-3">
<h3 className=' text-white text-[23px] mx-auto md:w-max'>به داشبورد خود خوش آمدید</h3>
</div>
<div className='SideBar-menu block py-[38px] ' >
<ul className=' list-item list-none text-white text-[23px] cursor-pointer'>
<li><NavLink to={'/'} className="item mb-[25px] flex ps-6  py-[17px]"> <AiOutlineHome className=' me-1'/>صفحه اصلی</NavLink></li>
<li><NavLink to={'/Products'} className={`${(link)=>link.isActive?'active':''}  item flex ps-6 py-[17px]`}><MdProductionQuantityLimits className=' me-1 '/>محصولات</NavLink></li>
<li><NavLink to={'/Comments'} className="item flex ps-6  py-[17px]"><BiCommentDetail className=' me-1'/>کامنت ها</NavLink></li>
<li><NavLink to={'/Users'} className="item flex ps-6  py-[17px]">< FiUsers className=' me-1'/>کاربران</NavLink></li>
<li><NavLink to={'/Orders'} className="item flex ps-6  py-[17px]"><BsBagCheck className=' me-1'/>سفارشات</NavLink></li>
<li><NavLink to={'/Discounts'} className="item flex ps-6  py-[17px]">< BsCurrencyDollar className=' me-1'/>تخفیف ها</NavLink></li>
</ul>
</div>
    </div>
    </>
  )
}
