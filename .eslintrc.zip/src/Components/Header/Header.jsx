import React from 'react'
import './Header.css'
import LightModeOutlinedIcon from '@mui/icons-material/LightModeOutlined';
import NotificationsNoneOutlinedIcon from '@mui/icons-material/NotificationsNoneOutlined';
export default function Header() {
  return (
    <>
    <div className='Wrapp-Header bg-gray-white w-full flex justify-between py-[19px]'>
       <div className="admin-person Right-side ms-10">
        <div className="img-person flex gap-x-4 ">
            <img src="img/amir.jpg" alt="" className=' size-14 rounded-full' />
            <div className="admin-name mt-1.5"> 
            <h4 className=' text-[21px]'>محمدامین سعیدی راد</h4>
            <h4 className=' text-[17px] text-gray-600'>برنامه نویس </h4>
            </div>
        </div>
       </div>
       <div className=' Left-side  flex me-5 text-white gap-x-5' >
        <div className="search-box">
          <input type="text" placeholder='جست جو کنید... ' />
          <button>جستجو</button>
        </div>
        <button className='   lefSide-icons'>
<NotificationsNoneOutlinedIcon />
        </button>
        <button className='   lefSide-icons'>
<LightModeOutlinedIcon />
        </button>
       </div>
    </div>
    </>
  )
}
