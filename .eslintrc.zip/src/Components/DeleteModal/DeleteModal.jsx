import React, { useEffect } from 'react'
import ReactDom from 'react-dom'
//
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import Notif from '../Notif/Notif';
import './DeleteModal.css'
export default function DeleteModal(props) {
  // console.log(props);
    const [open, setOpen] = React.useState(true);
    // const handleClickOpen = () => {
    //   setOpen(true);
    // };
    const handleClose = () => {
      props.setIsdelete(false)
      setOpen(false);
    };
    //
    
  return  ReactDom.createPortal(
<>
      <Dialog 
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title" >
          {"حذف"}
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description" className='  font-bold ' style={{fontSize:20}}>
          آیا از حذف این محصول اطمینان دارید؟
          </DialogContentText>
        </DialogContent>
        <DialogActions >
          <Button onClick={()=>{props.submitModal()}}>
            بله</Button>
          <Button onClick={handleClose}>
            خیر
          </Button>
        </DialogActions>
      </Dialog>
</>
  ,
    document.getElementById('modal')
  )
    
}
