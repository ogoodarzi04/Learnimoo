import React, { useEffect, useRef, useState } from 'react'
import ReactDom from 'react-dom'
//
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import useEdit from '../../useEdit';
//

//
export default function EditModal(props) {
  // console.log(props);
    const [open, setOpen] = useState(true);
    //
  const [newImg,setNewImg]=useState()
  const [newName,setNewName]=useState()
  const [newCount,setNewCount]=useState()
  const [newPrice,setNewPrice]=useState()
  const [newPopularity,setNewPopularity]=useState()
  const [newColors,setNewColors]=useState()
  const [newSale,setNewSale]=useState()
  //
  const {editedata,editepost,setEditepost,errorr}=useEdit()
    //
    // const inputValueRef=useRef()
    // useEffect(()=>{
    //   console.log(inputValueRef.current)
    //   // getValueinput()
    //  },[])
    //  const getValueinput=()=>{
    //    console.log(inputValueRef.current)
    //  }
    const handleClose = () => {
      setOpen(false);
      props.setIseditemodal(false)
    };
     //
     const editesubmitModal=(e)=>{
      e.preventDefault()
  editedata('http://localhost:8000/api/products'
    ,props.isEdit,newImg,newName,newCount,newPrice,newPopularity,newColors,newSale
  )
//   const newData={
//     title:newName,
//     price:newPrice,
//     count:newCount,
//     img :newImg,
//     popularity:newPopularity,
//     sale:newSale,
//     colors:newColors
// }
// console.log(newData);
// fetch(`http://localhost:8000/api/products/${props.isEdit}`,{
//     method:"PUT",
//     headers:{
//         'Content-Type':'application/json'
//     },
  
//     body:JSON.stringify(newData)
// })
// .then(res=>res.json())
// .then(data=>{
//     setEditepost(data)
//     console.log(data);
// }

// )
// .catch(errorr=>console.log(errorr))
//   props.update('http://localhost:8000/api/products')
}
useEffect(()=>{
  console.log(editepost);
    },[editepost])

    return  ReactDom.createPortal(
        <>
        <div className='wrapper-modal'  >
        <Dialog
        open={open}
        onClose={handleClose}
        PaperProps={{
          component: 'form',
          onSubmit: (event) => {
            event.preventDefault();
            const formData = new FormData(event.currentTarget);
            const formJson = Object.fromEntries(formData.entries());
            // const email = formJson.email;
            // console.log(email);
            handleClose();
          },
        }}
      >
        <DialogTitle>ثبت اطلاعات جدید</DialogTitle>
        <DialogContent>
          <DialogContentText>
            {/* To subscribe to this website, please enter your email address here. We
            will send updates occasionally. */}
          برای تغییر اطلاعات عکس محصول 
         ،لطفا فایل جدید مورد نظر را اینجا آپلود کنید 
          </DialogContentText>
   <TextField
            // ref={inputValueRef}
            autoFocus
            required
            margin="dense"
            id="photo"
            name="photo"
            label="عکس"
            type='file'
            fullWidth
            variant="standard"
            onChange={(e)=>{setNewImg(e.target.value)}}
          />
        </DialogContent>
        <DialogContent>
          <DialogContentText>
          برای تغییر اطلاعات نام محصول 
          ،لطفا اسم جدید مورد نظر را اینجا وارد کنید 
          </DialogContentText>
          <TextField
          //  ref={inputValueRef}
            autoFocus
            required
            margin="dense"
            id="name"
            name="name"
            label="نام محصول"
            type="text"
            fullWidth
            variant="standard"
            onChange={(e)=>{setNewName(e.target.value)}}
          />
        </DialogContent>    
          <DialogContent>
          <DialogContentText>
          برای تغییر اطلاعات موجودی محصول 
          ،لطفا مقدار جدید مورد نظر را اینجا وارد کنید 
          </DialogContentText>
          <TextField
          // ref={inputValueRef}
            autoFocus
            required
            margin="dense"
            id="count"
            name="count"
            label="موجودی"
            type="number"
            fullWidth
            variant="standard"
            onChange={(e)=>{setNewCount(e.target.value)}}
          />
        </DialogContent> 
             <DialogContent>
          <DialogContentText>
          برای تغییر اطلاعات قیمت محصول 
          ،لطفا مقدار جدید مورد نظر را اینجا وارد کنید 
          </DialogContentText>
          <TextField
        //  ref={inputValueRef}
            autoFocus
            required
            margin="dense"
            id="price"
            name="price"
            label="قیمت"
            type="number"
            fullWidth
            variant="standard"
            onChange={(e)=>{setNewPrice(e.target.value)}}
          />
        </DialogContent>
        <DialogContent>
          <DialogContentText>
          برای تغییر اطلاعات سطح محبوبیت محصول 
          ،لطفا مقدار جدید مورد نظر را اینجا وارد کنید 
          </DialogContentText>
          <TextField
        //  ref={inputValueRef}
            autoFocus
            required
            margin="dense"
            id="popularity"
            name="popularity"
            label="میزان محبوبیت"
            type="number"
            fullWidth
            variant="standard"
            onChange={(e)=>{setNewPopularity(e.target.value)}}
          />
        </DialogContent>
        <DialogContent>
          <DialogContentText>
          برای تغییر اطلاعات رنگ بندی محصول 
          ،لطفا رنگ جدید مورد نظر را اینجا وارد کنید 
          </DialogContentText>
          <TextField
        //  ref={inputValueRef}
            autoFocus
            required
            margin="dense"
            id="colors"
            name="colors"
            label="رنگ بندی"
            type="text"
            fullWidth
            variant="standard"
            onChange={(e)=>{setNewColors(e.target.value)}}
          />
        </DialogContent>
        <DialogContent>
          <DialogContentText>
          برای تغییر اطلاعات رنگ بندی محصول 
          ،لطفا رنگ جدید مورد نظر را اینجا وارد کنید 
          </DialogContentText>
          <TextField
        //  ref={inputValueRef}
            autoFocus
            required
            margin="dense"
            id="sale"
            name="sale"
            label="میزان فروش"
            type="number"
            fullWidth
            variant="standard"
            onChange={(e)=>{setNewSale(e.target.value)}}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>لغو</Button>
          <Button type="submit"  onClick={editesubmitModal}
          >ویرایش</Button>
        </DialogActions>
      </Dialog>  
        </div> 
        </>
      ,
    document.getElementById('modal')
      )
}      

//

