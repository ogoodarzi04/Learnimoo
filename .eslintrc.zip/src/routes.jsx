import MainPage from "./pages/MainPage/MainPage"
import Products from "./pages/Products/Products"
import Comments from "./pages/Comments/Comments"
import Users from "./pages/Users/Users"
import Orders from "./pages/Orders/Orders"
import Discounts from "./pages/Discounts/Discounts"
let routes=[
     {path:'/',element:<MainPage/>},
     {path:'/Products',element:<Products/>},
     {path:'/Comments',element:<Comments/>},
     {path:'/Users',element:<Users/>},
     {path:'/Orders',element:<Orders/>},
     {path:'/Discounts',element:<Discounts/>}
]
export default routes