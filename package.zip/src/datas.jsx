
const TABLE_HEAD = ["عکس", "اسم", "قیمت", "موجودی"];
//
const TABLE_ROWS = [
    {
      id:1,
      img: "images/head.jpeg",
      name: "John Michael",
      price: 2_000_000,
      count: "18",
    },
    {
      id:2,
      img: "images/headphone.jpeg",
      name: "John Michael",
      price: 2_000_000,
      count: "18",
    },
    {
      id:3,
      img: "images/charger.jpeg",
      name: "John Michael",
      price: 2_000_000,
      count: "18",
    },
    {
      id:4,
      img: "images/iphone.jpeg",
      name: "John Michael",
      price: 2_000_000,
      count: "18",
    },
    {
      id:5,
       img: "images/monitor.jpeg",
      name: "John Michael",
      price: 2_000_000,
      count: "18",
    },
    {
      id:6,
      img: "images/tshirt.jpeg",
     name: "John Michael",
     price: 2_000_000,
     count: "18",
   }, 
    {
      id:7,
    img: "images/soap.jpeg",
   name: "John Michael",
   price: 2_000_000,
   count: "18",
  },
  {
    id:8,
    img: "images/oil.jpeg",
   name: "John Michael",
   price: 2_000_000,
   count: "18",
  },
  ];
  //
export {TABLE_HEAD,TABLE_ROWS}
