import React, { useState } from 'react'
import ReactDom from 'react-dom'
//
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
//
export default function EditModal(props) {
    const [open, setOpen] = useState(true);
  
    const handleClose = () => {
      setOpen(false);
      props.setIseditemodal(false)
    };
    //
    return  ReactDom.createPortal(
        <>
         <Dialog
        open={open}
        onClose={handleClose}
        PaperProps={{
          component: 'form',
          onSubmit: (event) => {
            event.preventDefault();
            const formData = new FormData(event.currentTarget);
            const formJson = Object.fromEntries(formData.entries());
            const email = formJson.email;
            console.log(email);
            handleClose();
          },
        }}
      >
        <DialogTitle>ثبت اطلاعات جدید</DialogTitle>
        <DialogContent>
          <DialogContentText>
            {/* To subscribe to this website, please enter your email address here. We
            will send updates occasionally. */}
          برای تغییر اطلاعات عکس محصول 
         ،لطفا فایل جدید مورد نظر را اینجا آپلود کنید 
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="photo"
            name="photo"
            label="عکس"
           type='file'
            fullWidth
            variant="standard"
          />
        </DialogContent>
        <DialogContent>
          <DialogContentText>
          برای تغییر اطلاعات نام محصول 
          ،لطفا اسم جدید مورد نظر را اینجا وارد کنید 
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="name"
            name="name"
            label="نام محصول"
            type="text"
            fullWidth
            variant="standard"
          />
        </DialogContent>      <DialogContent>
          <DialogContentText>
          برای تغییر اطلاعات موجودی محصول 
          ،لطفا مقدار جدید مورد نظر را اینجا وارد کنید 
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="count"
            name="count"
            label="موجودی"
            type="number"
            fullWidth
            variant="standard"
          />
        </DialogContent>      <DialogContent>
          <DialogContentText>
          برای تغییر اطلاعات قیمت محصول 
          ،لطفا مقدار جدید مورد نظر را اینجا وارد کنید 
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="price"
            name="price"
            label="قیمت"
            type="number"
            fullWidth
            variant="standard"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>لغو</Button>
          <Button type="submit">ویرایش</Button>
        </DialogActions>
      </Dialog>
        </>
      ,
    document.getElementById('modal')
      )
}

//

