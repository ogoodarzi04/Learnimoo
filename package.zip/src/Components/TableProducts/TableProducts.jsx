import React, { useEffect, useState,usefe } from 'react'
import './TableProducts.css'
//
import {
  Card,
  Typography,
  CardBody,
  Avatar,
} from "@material-tailwind/react";
//
 import DeleteModal from '../DeleteModal/DeleteModal';
 import DetailsModal from '../DetailsModal/DetailsModal';
 import EditModal from '../EditModal/EditModal';
 //
 import { TABLE_HEAD,TABLE_ROWS } from '../../datas';
 //
 import useFetch from '../../useFetch';
 //
export default function TableProducts() {
  const [isdelete,setIsdelete]=useState(false)
  const [isdetails,setIsdetails]=useState(false)
  const [iseditemodal,setIseditemodal]=useState(false)
  //
  const {post,isPending,err}=useFetch(' http://localhost:8000/api/products/')

  useEffect(()=>{
    // console.log(post);
    fetch('http://localhost:8000/api/products/').then((res)=>res.json()).then((data)=>console.log(data))
  },[])
//
  return (
    <>
    <div className='TableProducts mt-4  ms-9 pe-6 bg-gray-white '>
        <div className=' rounded-[15px] relative p-4 bg-white '>
<Card className="h-full w-full ">
      <CardBody className=" px-0 w-full">
        <table className="mt-4 w-full min-w-max table-auto text-left ">
          <thead>
            <tr>
              {TABLE_HEAD.map((head, id) => (
                <th
                  key={head}
                  className="cursor-pointer  p-4 "
                >
                  <Typography
                    variant="small"
                    color="blue-gray"
                    className="flex items-center justify-between gap-2 font-normal leading-none  text-black"
                  >
                    {head}
                  </Typography>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {TABLE_ROWS.map(
              ({ img, name,price,count,id }) => {
                const isLast = id === TABLE_ROWS.length - 1;
                const classes = isLast
                  ? "p-4"
                  : "p-4 border-b border-blue-gray-50";
 
                return (
                  <tr key={id}>
                    <td className={classes}>
                      <div className="flex items-center gap-3  ">
                        <Avatar src={img} alt={name}  className=' size-32 '/>
                      </div>
                    </td>
                    <td className={classes}>
                      <div className="flex items-center gap-3">
                        <Typography
                          variant="small"
                          color="blue-gray"
                          className="font-normal opacity-70"
                        >
                          {name}
                        </Typography>
                      </div>
                    </td>
                    <td className={classes}>
                      <div className="flex items-center gap-3">
                        <Typography
                          variant="small"
                          color="blue-gray"
                          className="font-normal opacity-70"
                        >
                          {price}
                        </Typography>
                      </div>
                    </td>
                    <td className={classes}>
                      <div className="flex items-center gap-3">
                        <Typography
                          variant="small"
                          color="blue-gray"
                          className="font-normal opacity-70"
                        >
                          {count}
                        </Typography>
                      </div>
                    </td>
                    <td className='flex gap-x-6 md:w-max mx-auto'>
   <button className='search-btn2 text-white  mt-[12px] text-[18px] bg-teal-500 ' onClick={()=>setIsdetails(true)}  >جزییات</button>
  <button className='search-btn2 text-white  mt-[12px] text-[18px] bg-red-700 ' onClick={()=>setIsdelete(true)}   >حذف</button>
  <button className='search-btn2 text-white  mt-[12px] text-[18px]  '   style={{backgroundColor:'rgb(20, 8, 96)'}}   onClick={()=>setIseditemodal(true)}  >ویرایش</button>
                    </td>
                  </tr>
                );
              },
            )}
          </tbody>
        </table>
      </CardBody>
    </Card>
        </div>
    </div>
    {isdelete&&<DeleteModal isdelete={isdelete} setIsdelete={setIsdelete} />}
    {isdetails&&<DetailsModal isdetails={isdetails} setIsdetails={setIsdetails} />}
    {iseditemodal&&<EditModal iseditemodal={iseditemodal} setIseditemodal={setIseditemodal} />}
    </>
  )
}

