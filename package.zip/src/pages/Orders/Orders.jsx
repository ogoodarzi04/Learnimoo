import React from 'react'
import './Orders.css'
import ErrBox from '../../Components/ErrBox/ErrBox'
export default function Orders() {
  return (
    <div>Orders
<ErrBox titleErr={'سفارشی'}/>
    </div>
  )
}
