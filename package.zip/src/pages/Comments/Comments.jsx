import React from 'react'
import './Comments.css'
import ErrBox from '../../Components/ErrBox/ErrBox'
export default function Comments() {
  return (
    <div>Comments
<ErrBox titleErr={'کامنتی'}/>
    </div>
  )
}
