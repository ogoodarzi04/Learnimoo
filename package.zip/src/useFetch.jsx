import React from 'react'
import { useState,useEffect} from 'react'
export default function useFetch(url) {
    const [post,setPost]=useState(null)
    const [isPending,setisPending]=useState(true)
    const [err,setErr]=useState(null)
    useEffect(()=>{
        // setTimeout(() => {
            fetch(url)
            .then(post=>post.json()
            .then(data=>{
         setPost(data)
         setisPending(false)
        setErr(null)
        }
    
    )
)
.catch(err=>console.log(err))
        // },);
      
    },[])
    return {post,isPending,err}
}
