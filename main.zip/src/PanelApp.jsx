import React, { useState } from 'react'
import './PanelApp.css'
import SideBar from './Components/SideBar/SideBar'
import Header from './Components/Header/Header'
//
import { useRoutes } from 'react-router-dom'
import routes from './routes'
import ErrBox from './Components/ErrBox/ErrBox'
import { ContextProvider } from './contexts/Context'
import Modal from './Components/DeleteModal/DeleteModal'
//
export default function PanelApp() {
  const router=useRoutes(routes)
  //
  return (
    <ContextProvider>
    <>
    <div className=' grid md:grid-cols-7 bg-gray-white  h-screen relative'  dir='rtl'>
        <div className=' col-span-1 flex top-0' style={{position:'sticky'}}>
    <SideBar/>
        </div>
        <div className="col-span-6">
    <Header/>
        <div className=' routers'>
{router}
        </div>
        </div>
    </div>
    </>
    </ContextProvider>
  )
}
