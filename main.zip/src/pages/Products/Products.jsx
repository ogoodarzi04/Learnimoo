import React, { useEffect,useContext, useState } from 'react'
import './Products.css'
import ErrBox from '../../Components/ErrBox/ErrBox';
import { Context } from '../../contexts/Context'
import AddNewProduct from '../../Components/AddNewProduct/AddNewProduct';
import TableProducts from '../../Components/TableProducts/TableProducts';
export default function Products() {
  return (
    <>
  <div className='ProductPage bg-gray-white'>
<AddNewProduct/>
<TableProducts/>
<br /><br />
  </div>
    </>
  )
 
}
