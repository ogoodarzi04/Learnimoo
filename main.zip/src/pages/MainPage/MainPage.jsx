import React from 'react'
import './MainPage.css'
export default function MainPage() {
  return (
    <div>MainPage</div>
  )
}
