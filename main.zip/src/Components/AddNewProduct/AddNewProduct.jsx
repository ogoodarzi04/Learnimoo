import React, { useEffect,useContext, useState } from 'react'
// import './Products.css'
import ModeEditOutlineOutlinedIcon from '@mui/icons-material/ModeEditOutlineOutlined';
import WorkOutlineIcon from '@mui/icons-material/WorkOutline';
import PanoramaOutlinedIcon from '@mui/icons-material/PanoramaOutlined';
import { BsBagCheck, BsCurrencyDollar } from "react-icons/bs";
import { Context } from '../../contexts/Context'
//
import usePost from '../../usePost';
//
export default function AddNewProduct() {
    const context=useContext(Context)
    const [inputproduct,setInputproduct]=useState([])
    const [inputvalue,setInputvalue]=useState('')
    //
    const [nameAdd,setNameAdd]=useState()
    const [priceAdd,setPriceAdd]=useState()
    const [saleAdd,setSaleAdd]=useState()
    const [popularityAdd,setPopularityAdd]=useState()
    const [countAdd,setCountAdd]=useState()
    const [colorsAdd,setColorsAdd]=useState()
    const [imageAdd,setImageAdd]=useState()
//
const {postdata,postpost,setPostpost,errorrs}=usePost()
//

    const inputDes=()=>{
      document.querySelectorAll('.input-product').forEach((item)=>{
        item.onkeyup=(e)=>{
          setInputvalue(e.target.value)
   if(inputvalue){
    // setInputvalue(e.target.value)
     e.target.nextSibling.style.visibility='hidden'
     e.target.nextSibling.nextSibling.style.visibility='hidden'
   }
    else{
      // setInputvalue(e.target.value)
  e.target.nextSibling.style.visibility='visible'
          e.target.nextSibling.nextSibling.style.visibility='visible'
   }
        }
      })
    }
    useEffect(()=>{
     inputDes()
    },[inputvalue])
    //
  const AddProducts=(e)=>{    
    e.preventDefault()
//
    postdata('http://localhost:8000/api/products'
      ,nameAdd,imageAdd,priceAdd,countAdd,popularityAdd,colorsAdd,saleAdd
    )
    console.log(postpost);
  }
    return (
      <>
      <div className=' Add-NewProducts   ms-9 pe-6'>
      <div className="Title-Product mt-10">
    <h2 className=' text-[35px]'>
      افزودن محصول جدید
    </h2>
  </div>
    <div className='Label-Products bg-white mt-[29px] rounded-[15px] relative'>
  <div className=' grid md:grid-cols-2 p-4 gap-x-4 cursor-pointer'>
    <div className='Name-Product bg-gray-white py-[12px] rounded-[11px] flex px-6 relative'><input className='input-product size-full bg-gray-white border-none' onChange={(e)=>setNameAdd(e.target.value)} value={nameAdd}/><ModeEditOutlineOutlinedIcon className=' icon-products absolute'/><p className=' absolute ms-12 mt-1'>اسم محصول را بنویسید</p></div>
    <div className='Stock-Product bg-gray-white py-[12px] rounded-[11px] flex px-6 '><input className='input-product size-full bg-gray-white border-none' onChange={(e)=>setCountAdd(e.target.value)} value={countAdd}/><WorkOutlineIcon className=' icon-products  absolute'/><p className=' ms-12 mt-1 absolute'>موجودی محصول را بنویسید</p></div>
    <div className='Price-Product bg-gray-white py-[12px] rounded-[11px] flex px-6 mt-2.5'><input className='input-product size-full bg-gray-white border-none' onChange={(e)=>setPriceAdd(e.target.value)} value={priceAdd}/><BsCurrencyDollar className=' icon-products  size-[23px] absolute'/><p className=' ms-12 mt-1 absolute'>قیمت محصول را بنویسید</p></div>
    <div className='Picture-Product bg-gray-white py-[12px] rounded-[11px] flex px-6 mt-2.5'><input className='input-product size-full bg-gray-white border-none' onChange={(e)=>setImageAdd(e.target.value)} value={imageAdd}/><PanoramaOutlinedIcon className=' icon-products  absolute'/><p className=' ms-12 mt-1 absolute'>آدرس عکس محصول را بنویسید</p></div>
    <div className='Price-Product bg-gray-white py-[12px] rounded-[11px] flex px-6 mt-2.5'><input className='input-product size-full bg-gray-white border-none'  onChange={(e)=>setPopularityAdd(e.target.value)} value={popularityAdd}/><BsCurrencyDollar className=' icon-products  size-[23px] absolute'/><p className=' ms-12 mt-1 absolute'>سطح محبوبیت محصول را بنویسید</p></div>
    <div className='Picture-Product bg-gray-white py-[12px] rounded-[11px] flex px-6 mt-2.5'><input className='input-product size-full bg-gray-white border-none' onChange={(e)=>setSaleAdd(e.target.value)} value={saleAdd}/><PanoramaOutlinedIcon className=' icon-products  absolute' /><p className=' ms-12 mt-1 absolute'>میزان فروش محصول را بنویسید</p></div>
    <div className='Price-Product bg-gray-white py-[12px] rounded-[11px] flex px-6 mt-2.5'><input className='input-product size-full bg-gray-white border-none' onChange={(e)=>setColorsAdd(e.target.value)} value={colorsAdd}/><BsCurrencyDollar className=' icon-products  size-[23px] absolute' /><p className=' ms-12 mt-1 absolute z-50'>رنگ بندی محصول را بنویسید</p></div>
  </div>
  <button className='search-btn text-white bg-slate-500  mt-[12px] text-[18px]  absolute left-7 bottom-4' onClick={AddProducts} >ثبت محصول</button>
  </div>
      </div>
      </>
    )
}
