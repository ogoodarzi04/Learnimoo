import React, { useEffect, useMemo, useRef, useState } from 'react'
import ReactDom from 'react-dom'
//
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import useEdit from '../../useEdit';
//

//
export default function EditModal(props) {
  // console.log(props.items);
    const [open, setOpen] = useState(true);
    //
  const [newImg,setNewImg]=useState()
  const [newName,setNewName]=useState()
  const [newCount,setNewCount]=useState()
  const [newPrice,setNewPrice]=useState()
  const [newPopularity,setNewPopularity]=useState()
  const [newColors,setNewColors]=useState()
  const [newSale,setNewSale]=useState()
  //
  const [isModal,setIsModal]=useState()
  const [itmei,setItemi]=useState([])
  //
  const {editedata,editepost,setEditepost,errorr}=useEdit()
    const handleClose = () => {
      setOpen(false);
      props.setIseditemodal(false)
    };
    //
    
    useEffect(()=>{
     let findEditItem=props.items.find((i)=>{
        return i.id===props.isEdit
      })
      // console.log(findEditItem);
      setItemi(findEditItem)
      // console.log(newName);
      setNewName(itmei.title)
      setNewImg(itmei.img)
      setNewCount(itmei.count)
      setNewPrice(itmei.price)
      setNewPopularity(itmei.popularity)
      setNewColors(itmei.colors)
      setNewSale(itmei.sale)
    },[props.isEdit,itmei])
    //
    const editesubmitModal=(e)=>{   
      handleClose();
      //  
  editedata('http://localhost:8000/api/products'
    ,props.isEdit,newImg,newName,newCount,newPrice,newPopularity,newColors,newSale
  )
  props.update('http://localhost:8000/api/products')
  props.update('http://localhost:8000/api/products');
  // setIsModal(prev=>!prev)
 
}
// useEffect(()=>{
//   // setIsModal(true)
//   console.log(isModal);
// },[isModal])
    //
  //   useMemo(()=>{
  // return setIsModal(prev=>!prev)
  //   },[])

    return  ReactDom.createPortal(
        <>
        <div className='wrapper-modal'  >
 <Dialog
        open={open}
        onClose={handleClose}
        PaperProps={{
          component: 'form',
          onSubmit: (event) => {
            event.preventDefault();
            const formData = new FormData(event.currentTarget);
            const formJson = Object.fromEntries(formData.entries());
            // const email = formJson.email;
            // console.log(email);
            handleClose();
          },
        }}
      >
        <DialogTitle>ثبت اطلاعات جدید</DialogTitle>
        {/* <DialogContent>
          <DialogContentText>
          برای تغییر اطلاعات عکس محصول 
         ،لطفا فایل جدید مورد نظر را اینجا آپلود کنید 
          </DialogContentText>
   <TextField
            // ref={inputValueRef}
            autoFocus
            required
            margin="dense"
            id="photo"
            name="photo"
            label="عکس"
            type='file'
            fullWidth
            variant="standard"
            // value={}
            onChange={(e)=>setNewImg(e.target.value)}
     />
        </DialogContent> */}
        <DialogContent>
          <DialogContentText>
          برای تغییر اطلاعات نام محصول 
          ،لطفا اسم جدید مورد نظر را اینجا وارد کنید 
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="name"
            name="name"
            label="نام محصول"
            type="text"
            fullWidth
            variant="standard"
            value={newName}
            onChange={(e)=>{setNewName(e.target.value)}}
          />
        </DialogContent>    
          <DialogContent>
          <DialogContentText>
          برای تغییر اطلاعات موجودی محصول 
          ،لطفا مقدار جدید مورد نظر را اینجا وارد کنید 
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="count"
            name="count"
            label="موجودی"
            type="number"
            fullWidth
            variant="standard"
            value={newCount}
            onChange={(e)=>{setNewCount(e.target.value)}}
      />
        </DialogContent> 
             <DialogContent>
          <DialogContentText>
          برای تغییر اطلاعات قیمت محصول 
          ،لطفا مقدار جدید مورد نظر را اینجا وارد کنید 
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="price"
            name="price"
            label="قیمت"
            type="number"
            fullWidth
            variant="standard"
            value={newPrice}
            onChange={(e)=>{setNewPrice(e.target.value)}}
      />
        </DialogContent>
        <DialogContent>
          <DialogContentText>
          برای تغییر اطلاعات سطح محبوبیت محصول 
          ،لطفا مقدار جدید مورد نظر را اینجا وارد کنید 
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="popularity"
            name="popularity"
            label="میزان محبوبیت"
            type="number"
            fullWidth
            variant="standard"
            value={newPopularity}
            onChange={(e)=>{setNewPopularity(e.target.value)}}
          />
        </DialogContent>
        <DialogContent>
          <DialogContentText>
          برای تغییر اطلاعات رنگ بندی محصول 
          ،لطفا رنگ جدید مورد نظر را اینجا وارد کنید 
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="colors"
            name="colors"
            label="رنگ بندی"
            type="text"
            fullWidth
            variant="standard"
            value={newColors}
            onChange={(e)=>{setNewColors(e.target.value)}}
       />
        </DialogContent>
        <DialogContent>
          <DialogContentText>
          برای تغییر اطلاعات رنگ بندی محصول 
          ،لطفا رنگ جدید مورد نظر را اینجا وارد کنید 
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="sale"
            name="sale"
            label="میزان فروش"
            type="number"
            fullWidth
            variant="standard"
            value={newSale}
            onChange={(e)=>{setNewSale(e.target.value)}}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>لغو</Button>
          <Button   onClick={editesubmitModal}
          >ویرایش</Button>
        </DialogActions>
      </Dialog>
        </div> 
        </>
      ,
    document.getElementById('modal')
      )
}      

//

