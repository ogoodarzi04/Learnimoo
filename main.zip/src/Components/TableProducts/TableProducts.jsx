import React, { useEffect, useMemo, useState,usefe } from 'react'
import './TableProducts.css'
//
import {
  Card,
  Typography,
  CardBody,
  Avatar,
} from "@material-tailwind/react";
//
 import DeleteModal from '../DeleteModal/DeleteModal';
 import DetailsModal from '../DetailsModal/DetailsModal';
 import EditModal from '../EditModal/EditModal';
 //
 import { TABLE_HEAD,TABLE_ROWS } from '../../datas';
 //
 import useFetch from '../../useFetch';
 import useDelete from '../../useDelete';
 //
import ErrBox from '../ErrBox/ErrBox';
import Notif from '../Notif/Notif';
 //
export default function TableProducts(props) {
  const [isdelete,setIsdelete]=useState(false)
  const [isdetails,setIsdetails]=useState(false)
  const [iseditemodal,setIseditemodal]=useState(false)
  const [productId,setProductId]=useState(null)
  const [productTitle,setProductTitle]=useState(null)
  const [isSureDelete,setIsSureDelete]=useState(false)
  // const [allProduct,setAllProduct]=useState()
  //

  //
  const {deletedata,deletepost,setDeletepost,error}=useDelete()
  // const {editedata,editepost,setEditepost,errorr}=useEdit()
 //
 const deletesubmitModal=()=>{
   deletedata('http://localhost:8000/api/products',productId)
   setIsdelete(false)
   setIsSureDelete(prev=>!prev)
   getAllProducts('http://localhost:8000/api/products')
   // console.log(productId);
  } 
  //
  
  //
  const {getAllProducts,post,isPending,err}=useFetch()
  useEffect(()=>{
    getAllProducts('http://localhost:8000/api/products')
    // console.log(post);
  },[])
  //

////
return (
  <>
  {post.length? <>
      <div className='TableProducts mt-4  ms-9 pe-6 bg-gray-white '>
          <div className=' rounded-[15px] relative p-4 bg-white '>
  <Card className="h-full w-full ">
        <CardBody className=" px-0 w-full">
          <table className="mt-4 w-full min-w-max table-auto text-left ">
            <thead>
              <tr>
                {TABLE_HEAD.map((head, id) => (
                  <th
                    key={head}
                    className="cursor-pointer  p-4 "
                  >
                    <Typography
                      variant="small"
                      color="blue-gray"
                      className="flex items-center justify-between gap-2 font-normal leading-none  text-black"
                    >
                      {head}
                    </Typography>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {post.map(
                (props) => {
                  // console.log(props.id);
                  const isLast = props.id === post.length - 1;
                  const classes = isLast
                    ? "p-4"
                    : "p-4 border-b border-blue-gray-50";
   
                  return (
                    <tr key={props.id}>
                      <td className={classes}>
                        <div className="flex items-center gap-3  ">
                          <Avatar src={props.img} alt={props.title}  className=' size-32 '/>
                        </div>
                      </td>
                      <td className={classes}>
                        <div className="flex items-center gap-3">
                          <Typography
                            variant="small"
                            color="blue-gray"
                            className="font-normal opacity-70"
                          >
                            {props.title}
                          </Typography>
                        </div>
                      </td>
                      <td className={classes}>
                        <div className="flex items-center gap-3">
                          <Typography
                            variant="small"
                            color="blue-gray"
                            className="font-normal opacity-70"
                          >
                            {props.price}
                          </Typography>
                        </div>
                      </td>
                      <td className={classes}>
                        <div className="flex items-center gap-3">
                          <Typography
                            variant="small"
                            color="blue-gray"
                            className="font-normal opacity-70"
                          >
                           {props.count}
                          </Typography>
                        </div>
                      </td>
                      <td className='flex gap-x-6 md:w-max mx-auto'>
     <button className='search-btn2 text-white  mt-[12px] text-[18px] bg-teal-500 ' onClick={()=>{setIsdetails(true),setProductId(props.id)}} >جزییات</button>
    <button className='search-btn2 text-white  mt-[12px] text-[18px] bg-red-700 ' onClick={()=>{setIsdelete(true),setProductId(props.id),setProductTitle(props.title)}}>حذف</button>
    <button className='search-btn2 text-white  mt-[12px] text-[18px]  '   style={{backgroundColor:'rgb(20, 8, 96)'}}   onClick={()=>{setIseditemodal(true),setProductId(props.id)}}  >ویرایش</button>
                      </td>
                    </tr>
                  );
                },
              )}
            </tbody>
          </table>
        </CardBody>
      </Card>
          </div>
      </div>
  {
  isdelete&&<DeleteModal isdelete={isdelete} setIsdelete={setIsdelete} submitModal={deletesubmitModal} deleteTitle={productTitle}/>
  }
      {isdetails&&<DetailsModal isdetails={isdetails} setIsdetails={setIsdetails} idDetails={productId} items={post} />}
      {iseditemodal&&<EditModal iseditemodal={iseditemodal} setIseditemodal={setIseditemodal} isEdit={productId} items={post} update={getAllProducts}
      //  submitEditeModal={editesubmitModal} 
       />
       }
      </>:<ErrBox titleErr={'محصولی'} />}
      {isSureDelete?<Notif productTitle={productTitle}/>:''}
      </>  )
}

