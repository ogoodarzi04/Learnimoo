import React from 'react'
import { useState,useEffect} from 'react'
export default function useFetch() {
    const [post,setPost]=useState([])
    const [isPending,setisPending]=useState(true)
    const [err,setErr]=useState(null)
    const getAllProducts=async(url)=>{
        try{
let res=await fetch(url)
let data=await res.json()
setPost(await data)
     setisPending(false)
    setErr(null)
 }
 catch{
    setErr(true)

 }

    }
  
    return {getAllProducts,post,isPending,err}
}
