import React from "react";
import MenusElement from "./menusElement";
export default function Menus() {
   return (
      <div className="Menus">
         <MenusElement isAddNewCmp={true} />
      </div>
   );
}
