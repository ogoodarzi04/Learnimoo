import React from "react";
import TicketsElement from "./TicketsElement";
//
export default function Tickets() {
   return (
      <div className="Tickets">
         <TicketsElement />
      </div>
   );
}
