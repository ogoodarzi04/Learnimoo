import React from "react";
import DiscountElement from "./DiscountElement";

export default function Discount() {
   return (
      <div className=" Discount">
         <DiscountElement isAddNewCmp={true} />
      </div>
   );
}
