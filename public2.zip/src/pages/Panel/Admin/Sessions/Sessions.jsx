import React from "react";
import SessionsElement from "./SessionsElement";
//
export default function Sessions() {
   return (
      <div className="Sessions">
         <SessionsElement isAddNewCmp={true} />
      </div>
   );
}
